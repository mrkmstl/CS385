import React, { Component } from "react";
import Welcome from "./Page0Welcome";
import Events from "./Page1Events";
import BDay from "./Page2Birthday";
import Wedding from "./Page3Wedding";
import Bachelor from "./Page4Bachelor";
import Baby from "./Page5Baby";
import Meeting from "./Page6Meeting";
import Date from "./Page7Date";
import Confirm from "./Page8Confirm";

/*
Mobile App for AJ's Events Ltd.

Developed by CS385 Team AmazonB:
- Adam Kelso, Danial Khwaja, Daniel Trundle and Marek Mistela

Our 3 Required Functionalities are:
      - Use of Conditional Rendering
      - Use of a selection of UI Elements
      - Use Parent-Child Communication
*/

class App extends Component {
  //Set up all of our state variables and bind our functions
  constructor(props) {
    super(props);
    this.state = {
      pg: 0,
      username: "",
      phoneNum: "",
      eventName: "",
      guests: "",
      venue: "",
      ageRange: "",
      budget: "",
      theme: "",
      requests: "",
      date: ""
    };
    this.setPage = this.setPage.bind(this);
    this.storeNumber = this.storeNumber.bind(this);
    this.storeUsername = this.storeUsername.bind(this);
    this.storeEventName = this.storeEventName.bind(this);
    this.storeGuests = this.storeGuests.bind(this);
    this.storeVenue = this.storeVenue.bind(this);
    this.storeAgeRange = this.storeAgeRange.bind(this);
    this.storeBudget = this.storeBudget.bind(this);
    this.storeTheme = this.storeTheme.bind(this);
    this.storeRequests = this.storeRequests.bind(this);
    this.storeDate = this.storeDate.bind(this);
  } // end constructor

  //All functions to call back variables from child components
  setPage(page) {
    this.setState({ pg: page });
  }

  storeNumber(number) {
    this.setState({ phoneNum: number });
  }

  storeUsername(name) {
    this.setState({ username: name });
  }

  storeEventName(name) {
    this.setState({ eventName: name });
  }

  storeGuests(num) {
    this.setState({ guests: num });
  }

  storeVenue(name) {
    this.setState({ venue: name });
  }

  storeAgeRange(range) {
    this.setState({ ageRange: range });
  }

  storeBudget(num) {
    this.setState({ budget: num });
  }

  storeTheme(name) {
    this.setState({ theme: name });
  }

  storeRequests(string) {
    this.setState({ requests: string });
  }

  storeDate(date) {
    this.setState({ date: date });
  }

  render() {
    return (
      <div>
        {/* Conditionally render each child component based on this.state.pg (page number) 
            Pass state variables and setState functions into each child component*/}
        {this.state.pg === 0 && (
          <Welcome
            storeUsername={this.storeUsername}
            storeNumber={this.storeNumber}
            setPage={this.setPage}
          />
        )}
        {this.state.pg === 1 && (
          <Events setPage={this.setPage} name={this.state.username} />
        )}
        {this.state.pg === 2 && (
          <BDay
            setPage={this.setPage}
            storeEventName={this.storeEventName}
            storeGuests={this.storeGuests}
            storeVenue={this.storeVenue}
            storeAgeRange={this.storeAgeRange}
            storeBudget={this.storeBudget}
            storeTheme={this.storeTheme}
            storeRequests={this.storeRequests}
          />
        )}
        {this.state.pg === 3 && (
          <Wedding
            setPage={this.setPage}
            storeEventName={this.storeEventName}
            storeGuests={this.storeGuests}
            storeVenue={this.storeVenue}
            storeBudget={this.storeBudget}
            storeTheme={this.storeTheme}
            storeRequests={this.storeRequests}
          />
        )}
        {this.state.pg === 4 && (
          <Bachelor
            setPage={this.setPage}
            storeEventName={this.storeEventName}
            storeGuests={this.storeGuests}
            storeVenue={this.storeVenue}
            storeBudget={this.storeBudget}
            storeTheme={this.storeTheme}
            storeRequests={this.storeRequests}
          />
        )}
        {this.state.pg === 5 && (
          <Baby
            setPage={this.setPage}
            storeEventName={this.storeEventName}
            storeGuests={this.storeGuests}
            storeVenue={this.storeVenue}
            storeBudget={this.storeBudget}
            storeTheme={this.storeTheme}
            storeRequests={this.storeRequests}
          />
        )}
        {this.state.pg === 6 && (
          <Meeting
            setPage={this.setPage}
            storeEventName={this.storeEventName}
            storeGuests={this.storeGuests}
            storeVenue={this.storeVenue}
            storeBudget={this.storeBudget}
            storeTheme={this.storeTheme}
            storeRequests={this.storeRequests}
          />
        )}
        {this.state.pg === 7 && (
          <Date setPage={this.setPage} storeDate={this.storeDate} />
        )}
        {this.state.pg === 8 && (
          <Confirm
            name={this.state.username}
            number={this.state.phoneNum}
            date={this.state.date}
            event={this.state.eventName}
            guests={this.state.guests}
            venue={this.state.venue}
            budget={this.state.budget}
            theme={this.state.theme}
            requests={this.state.requests}
          />
        )}
      </div>
    );
  }
}

export default App;
