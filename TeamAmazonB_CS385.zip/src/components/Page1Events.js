import "./styles.css";
import BirthdayCard from "./res/Birthday.png";
import WeddingCard from "./res/Wedding.png";
import BachelorParty from "./res/BachelorParty.png";
import BabyShower from "./res/BabyShower.png";
import Meeting from "./res/Meeting.png";
import React, { Component } from "react";

class Events extends Component {
  render() {
    return (
      <div>
        <h1 className="EventsText">Hi {this.props.name}!</h1>
        <h3 className="EventsText">Please select an Event</h3>
        <div className="Container">
          <button className="custom-btn">
            <img
              className="Birthday"
              src={BirthdayCard}
              alt="BirthdayCard"
              onClick={() => this.props.setPage(2)}
            />
          </button>
          <div className="BirthdayText">Birthday</div>
        </div>
        <div className="Container">
          <button className="custom-btn">
            <img
              className="Wedding"
              src={WeddingCard}
              alt="WeddingCard"
              onClick={() => this.props.setPage(3)}
            />
          </button>
          <div className="WeddingText">Wedding</div>
          <button className="custom-btn">
            <img
              className="BachelorParty"
              src={BachelorParty}
              alt="BachelorParty"
              onClick={() => this.props.setPage(4)}
            />
          </button>
          <div className="BachelorPartyText">
            Bachelor
            <br /> Party
          </div>
        </div>
        <div className="Container">
          <button className="custom-btn">
            <img
              className="BabyShower"
              src={BabyShower}
              alt="BabyShower"
              onClick={() => this.props.setPage(5)}
            />
          </button>
          <div className="BabyShowerText">Baby </div>
          <button className="custom-btn">
            <img
              className="Meeting"
              src={Meeting}
              alt="Meeting"
              onClick={() => this.props.setPage(6)}
            />
          </button>
          <div className="MeetingText">Meeting</div>
        </div>
      </div>
    );
  }
}
export default Events;
