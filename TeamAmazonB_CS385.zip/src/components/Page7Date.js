import React, { Component } from "react";
import Calendar from "react-calendar";
import "./Calendar.css";
import "./styles.css";

//This allows us to set the formatting style for the date
var options = {
  weekday: "long",
  year: "numeric",
  month: "long",
  day: "numeric"
};

class datePage extends Component {
  constructor(props) {
    super(props);
    // isSelected is false until we select a date
    // we set the selected date initially as NOW (new Date())
    this.state = {
      selectedDate: new Date(),
      isSelected: false
    };
    this.handleDateChange = this.handleDateChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  //On submission, change pages and pass the date back to parent
  handleSubmit() {
    this.props.setPage(8);
    this.props.storeDate(
      this.state.selectedDate.toLocaleDateString("en-US", options)
    );
  }
  // The callback for the date handler.
  // There is a parameter which provides us with the date
  // we can process the date in any way we require
  handleDateChange(theDate) {
    this.setState({ isSelected: true });
    this.setState({ selectedDate: theDate });
  }

  // boolean function to indicate if this date is in the future.
  isFuture() {
    return this.state.selectedDate > new Date();
  }

  render() {
    return (
      <div className="App">
        <br />
        <h1 className="EventsText">Date</h1>
        <center>
          <form>
            <div className="form-group">
              <Calendar
                dateFormat="MMMM d, yyyy"
                closeOnScroll={true}
                selected={this.state.selectedDate}
                onChange={this.handleDateChange}
              />
            </div>
          </form>
          <br />
          {/* If the date is in the future, display the selected date and render continue button*/}
          {this.isFuture() && this.state.isSelected && (
            <p>
              {this.state.selectedDate.toLocaleDateString("en-US", options)}
              <br />
              <br />
              <button onClick={this.handleSubmit} className="button1">
                Continue
              </button>
            </p>
          )}
          {/* If the date is not in the future, display error and render disabled button*/}
          {!this.isFuture() && (
            <p style={{ color: "red" }}>
              Please select a future date.
              <br />
              <br />
              <button className="button-disabled">Continue</button>
            </p>
          )}
        </center>
      </div>
    ); // end of return statement
  } // end of render function
} // end of class

export default datePage;
