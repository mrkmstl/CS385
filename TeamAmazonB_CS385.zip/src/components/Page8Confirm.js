import React, { Component } from "react";
import "./styles.css";

class Confirm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      phoneNum: "",
      eventName: "",
      guests: "",
      venue: "",
      ageRange: "",
      budget: "",
      theme: "",
      requests: ""
    };

    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit() {
    //Create confirmation pop-up
    alert(
      "Your details have been received, we will contact you by phone in the next 2-5 working days. You will now be taken back to the home screen. Thank you for choosing AJ's Events Ltd.!"
    );
    //Refresh the browser, returning to home screen and resarting the app
    window.location.reload(false);
  }

  render() {
    return (
      <div className="App">
        <h1 className="EventsText">Confirmation</h1>
        <center>
          <h3> Please check your details:</h3>
          <p style={{ color: "red" }}>
            If something is incorrect, please refresh and re-book your event.
          </p>
        </center>
        <h3 className="ConfirmText">
          Name: {this.props.name}
          <br />
          Phone Number: {this.props.number}
          <br />
          Event Title: {this.props.event}
          <br />
          Date: {this.props.date}
          <br />
          Number of Guests: {this.props.guests}
          <br />
          Venue: {this.props.venue}
          <br />
          Budget: €{this.props.budget}
          <br />
          Theme: {this.props.theme}
          <br />
          Special Requests: {this.props.requests}
          <br />
        </h3>
        <center>
          <button onClick={this.handleSubmit} className="button1">
            Confirm
          </button>
        </center>
      </div>
    );
  }
}
export default Confirm;
