import React, { Component } from "react";
import "./styles.css";

class Meeting extends Component {
  constructor(props) {
    super(props);
    this.state = {
      eventName: "",
      guests: "",
      venue: "",
      budget: "",
      theme: "",
      requests: ""
    };

    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit() {
    //Check if each required input is filled
    if (
      this.state.eventName &&
      this.state.guests &&
      this.state.venue &&
      this.state.budget
    ) {
      //Pass all form answers into parent component
      this.props.setPage(7);
      this.props.storeEventName(this.state.eventName);
      this.props.storeGuests(this.state.guests);
      this.props.storeVenue(this.state.venue);
      this.props.storeBudget(this.state.budget);
      this.props.storeTheme(this.state.theme);
      this.props.storeRequests(this.state.requests);
    }
  }

  handleInputChange(event) {
    const value = event.target.value;
    const name = event.target.name;

    this.setState({
      [name]: value
    });
  }

  render() {
    return (
      <div className="App">
        <h1 className="EventsText">Meeting</h1>
        <form className="formstyle">
          <center>
            <input
              name="eventName"
              required
              type="text"
              value={this.state.eventName}
              onChange={this.handleInputChange}
              placeholder="Event Title (Required):"
            />
            <input
              name="guests"
              required
              type="number"
              value={this.state.guests}
              onChange={this.handleInputChange}
              placeholder="No. of Guests (Required):"
            />
            <br />
            <input
              name="venue"
              required
              type="text"
              value={this.state.venue}
              onChange={this.handleInputChange}
              placeholder="Venue (Required):"
            />
            <br />
            <input
              name="budget"
              required
              type="number"
              value={this.state.budget}
              onChange={this.handleInputChange}
              placeholder="Budget (Required):"
            />
            <br />
            <input
              name="requests"
              type="text"
              value={this.state.requests}
              onChange={this.handleInputChange}
              placeholder="Special Request (Optional):"
            />

            <button onClick={this.handleSubmit} className="button1">
              Continue
            </button>
          </center>
        </form>
      </div>
    );
  }
}
export default Meeting;
