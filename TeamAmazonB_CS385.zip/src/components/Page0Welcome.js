import React, { Component } from "react";
import "./styles.css";

class Welcome extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      number: ""
    };

    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  //Function called when the continue button is pressed
  handleSubmit() {
    //Ensure required fields are filled before changing page and passing varaibles to parents
    if (this.state.username && this.state.number) {
      this.props.storeUsername(this.state.username);
      this.props.storeNumber(this.state.number);
      this.props.setPage(1);
    }
  }

  //Function to handle live updating of input boxes
  handleInputChange(event) {
    const value = event.target.value;
    const name = event.target.name;

    this.setState({
      [name]: value
    });
  }

  render() {
    return (
      <div className="App">
        <h1 className="EventsText">
          Welcome to
          <br /> AJ's Events Ltd.
        </h1>
        <br />
        <br />
        <br />
        <br />
        <center>
          <h3> Please enter your details: </h3>
        </center>
        <form className="formstyle1">
          <center>
            <input
              name="username"
              required
              type="text"
              value={this.state.username}
              onChange={this.handleInputChange}
              placeholder="Name:"
            />
            <input
              name="number"
              required
              type="number"
              className="no-arrow"
              value={this.state.number}
              onChange={this.handleInputChange}
              placeholder="Phone Number:"
            />
            <button onClick={this.handleSubmit} className="button1">
              Continue
            </button>
          </center>
        </form>
      </div>
    );
  }
}
export default Welcome;
